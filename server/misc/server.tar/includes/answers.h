/*
** answers.h for zappy in /u/all/mouafi_a/cu/rendu/c/zappy2010/serveur/includes
**
** Made by amine mouafik
** Login   <mouafi_a@epitech.net>
**
** Started on  Tue May  4 22:10:54 2010 amine mouafik
** Last update Mon Jun 14 15:59:47 2010 amine mouafik
*/

#ifndef __ANSWERS_H__
# define __ANSERS_H__

# define CONNECT	"BIENVENUE\n"
# define SUCCESS   	"ok\n"
# define FAILURE	"ko\n"
# define IGNORE		"ignore\n"
# define ELEVATION	"elevation en cours\n"

# define CONNECT_LEN	10
# define SUCCESS_LEN	3
# define FAILURE_LEN	3
# define IGNORE_LEN	7
# define ELEVATION_LEN	19

#endif
