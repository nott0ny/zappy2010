/*
** actions.c for zappy in /u/all/mouafi_a/cu/rendu/c/zappy2010/server/sources/
**
** Made by amine mouafik
** Login   <mouafi_a@epitech.net>
**
** Started on  Mon Jun  7 14:58:20 2010 amine mouafik
** Last update Thu Jun 10 19:34:03 2010 amine mouafik
*/

#include "server.h"
#include "ringbuffer.h"

#define CMD_SIZE	512;

void	player_fork(t_env *e, t_players *player)
{
  e = e;
  player = player;
}
